# config.py
OPENAI_API_KEY = "your-openai-api-key-here"
