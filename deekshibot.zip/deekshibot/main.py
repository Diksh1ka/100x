import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import openai
import webbrowser
import os
from config import OPENAI_API_KEY

# Initialize engines
listener = sr.Recognizer()
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)  # Female voice

# Set OpenAI Key
openai.api_key = OPENAI_API_KEY

def talk(text):
    engine.say(text)
    engine.runAndWait()

def take_command():
    try:
        with sr.Microphone() as source:
            print("🎤 Listening...")
            voice = listener.listen(source)
            command = listener.recognize_google(voice)
            command = command.lower()
            print(f"🗣️ You said: {command}")
    except:
        command = ""
    return command

def chatgpt_response(prompt):
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=100
        )
        answer = response.choices[0].text.strip()
        return answer
    except:
        return "Sorry, I couldn't connect to OpenAI."

def run_deekshibot():
    try:
        print("Assistant is starting...")  # Debugging line added
        talk("Hi Deekshi, I'm ready. What can I do for you?")
        while True:
            command = take_command()

            if 'play' in command:
                song = command.replace('play', '')
                talk(f"Playing {song}")
                pywhatkit.playonyt(song)

            elif 'time' in command:
                time = datetime.datetime.now().strftime('%I:%M %p')
                talk(f"The current time is {time}")

            elif 'open google' in command:
                talk("Opening Google")
                webbrowser.open("https://www.google.com")

            elif 'open youtube' in command:
                talk("Opening YouTube")
                webbrowser.open("https://www.youtube.com")
	   
            elif 'open netflix' in command or 'launch netflix' in command:
                talk("Opening Netflix")
                os.system('start explorer shell:AppsFolder\\4DF9E0F8.Netflix_mcm4njqhnhss8!Netflix.App')

            elif 'open whatsapp' in command or 'launch whatsapp' in command:
                talk("Opening WhatsApp")
                os.system('start explorer shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App')
	 

            elif 'who are you' in command or 'what can you do' in command:
                talk("I'm Deekshi Bot, your voice assistant. I can play music, open websites, tell the time, or answer questions.")

            elif 'exit' in command or 'bye' in command:
                talk("Goodbye Deekshi! Have a great day.")
                break

            elif command != "":
                response = chatgpt_response(command)
                talk(response)

    except Exception as e:
        print(f"Error: {e}")

# Run the assistant
if __name__ == "__main__":
    run_deekshibot()
