import { ExternalLink, Github, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import dreamPathImage from '@/assets/project-dreampath.jpg';
import timeTrackingImage from '@/assets/project-timetracking.jpg';
import attendanceImage from '@/assets/project-attendance.jpg';
import calculatorImage from '@/assets/project-calculator.jpg';

const Projects = () => {
  const projects = [
    {
      title: "Dream Path",
      description: "A comprehensive career guidance platform that helps students and professionals make informed career decisions. Features personalized recommendations, skill assessments, and career roadmaps.",
      image: dreamPathImage,
      technologies: ["Python", "Flask", "SQL", "HTML", "CSS"],
      features: [
        "Personalized career recommendations",
        "Interactive skill assessments",
        "Career roadmap visualization",
        "Professional guidance resources"
      ],
      status: "Featured",
      demoUrl: "#",
      githubUrl: "https://github.com/Diksh1ka"
    },
    {
      title: "Time Tracking System",
      description: "An efficient time management application designed for tracking work hours, generating detailed reports, and managing multiple projects simultaneously.",
      image: timeTrackingImage,
      technologies: ["Python", "SQL", "Data Visualization"],
      features: [
        "Multi-project time tracking",
        "Detailed time reports",
        "Data visualization charts",
        "Export functionality"
      ],
      status: "Production",
      demoUrl: "#",
      githubUrl: "https://github.com/Diksh1ka"
    },
    {
      title: "Student Attendance System",
      description: "A robust education-focused tracking tool that streamlines attendance management for educational institutions with real-time monitoring and reporting.",
      image: attendanceImage,
      technologies: ["Python", "SQL", "Database Management"],
      features: [
        "Real-time attendance tracking",
        "Student profile management",
        "Attendance analytics",
        "Automated reporting"
      ],
      status: "Educational",
      demoUrl: "#",
      githubUrl: "https://github.com/Diksh1ka"
    },
    {
      title: "Responsive Calculator",
      description: "A modern, responsive web calculator with an intuitive interface and comprehensive mathematical operations, optimized for all devices.",
      image: calculatorImage,
      technologies: ["HTML", "CSS", "JavaScript"],
      features: [
        "Responsive design",
        "Clean user interface",
        "Basic & advanced operations",
        "Cross-browser compatibility"
      ],
      status: "Web App",
      demoUrl: "#",
      githubUrl: "https://github.com/Diksh1ka"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Featured':
        return 'bg-gradient-primary text-white';
      case 'Production':
        return 'bg-green-500/20 text-green-400 border border-green-500/30';
      case 'Educational':
        return 'bg-blue-500/20 text-blue-400 border border-blue-500/30';
      case 'Web App':
        return 'bg-purple-500/20 text-purple-400 border border-purple-500/30';
      default:
        return 'bg-primary/20 text-primary border border-primary/30';
    }
  };

  return (
    <section id="projects" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            Featured <span className="gradient-text">Projects</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A showcase of my technical skills and creativity through various projects 
            spanning web development, data management, and user experience design.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="project-card group">
              {/* Project Image */}
              <div className="relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent"></div>
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                    {project.status}
                  </span>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Technologies */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-3 py-1 bg-secondary rounded-full text-sm text-secondary-foreground border border-border/50"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="font-semibold mb-2 text-foreground">Key Features:</h4>
                  <ul className="space-y-1">
                    {project.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-sm text-muted-foreground flex items-center gap-2">
                        <ArrowRight className="h-3 w-3 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex-1 border-primary/50 hover:bg-primary/10"
                    asChild
                  >
                    <a href={project.demoUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Demo
                    </a>
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex-1 border-primary/50 hover:bg-primary/10"
                    asChild
                  >
                    <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                      <Github className="h-4 w-4 mr-2" />
                      Source Code
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Projects Section */}
        <div className="text-center mt-12">
          <div className="glow-card inline-block">
            <div className="p-8">
              <h3 className="text-xl font-semibold mb-3">More Projects Coming Soon!</h3>
              <p className="text-muted-foreground mb-4">
                I'm constantly working on new projects and exploring innovative technologies.
              </p>
              <Button 
                variant="outline"
                className="border-primary/50 hover:bg-primary/10"
                asChild
              >
                <a href="https://github.com/Diksh1ka" target="_blank" rel="noopener noreferrer">
                  <Github className="h-4 w-4 mr-2" />
                  View All Projects
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;