import { Award, Calendar, Trophy, BookOpen, Users } from 'lucide-react';

const Achievements = () => {
  const achievements = [
    {
      title: "AWS Certified Cloud Practitioner",
      description: "Achieved AWS Cloud Practitioner certification, demonstrating foundational knowledge of AWS cloud services and best practices.",
      date: "2024",
      type: "Certification",
      icon: Award,
      status: "completed"
    },
    {
      title: "Google Cloud Computing Foundations (NPTEL)",
      description: "Completed comprehensive course on Google Cloud Computing fundamentals through NPTEL platform.",
      date: "Oct 2024",
      type: "Course Completion",
      icon: BookOpen,
      status: "completed"
    },
    {
      title: "Python for Data Science (IBM)",
      description: "Successfully completed IBM's Python for Data Science course, gaining expertise in data analysis and machine learning.",
      date: "Aug 2024",
      type: "Certification",
      icon: Award,
      status: "completed"
    },
    {
      title: "Power BI Job Simulation",
      description: "Completed hands-on Power BI job simulation, developing skills in data visualization and business intelligence.",
      date: "Sept 2024",
      type: "Simulation",
      icon: BookOpen,
      status: "completed"
    },
    {
      title: "Hackathon Participation & Awards",
      description: "Active participant in multiple hackathons, showcasing problem-solving skills and teamwork in competitive environments.",
      date: "2024",
      type: "Competition",
      icon: Trophy,
      status: "completed"
    }
  ];


  return (
    <section id="achievements" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            <span className="gradient-text">Achievements</span> & Certifications
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A journey of continuous learning and growth in technology and software development.
          </p>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="timeline-line"></div>
          
          <div className="space-y-8">
            {achievements.map((achievement, index) => (
              <div 
                key={index} 
                className={`relative flex gap-8 ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-6 lg:left-1/2 lg:transform lg:-translate-x-1/2">
                  <div className="timeline-dot"></div>
                </div>

                {/* Content Card */}
                <div className={`flex-1 ${index % 2 === 0 ? 'lg:pr-8' : 'lg:pl-8'} ml-16 lg:ml-0`}>
                  <div className="glow-card group">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-gradient-primary">
                        <achievement.icon className="h-6 w-6 text-white" />
                      </div>
                        <div className="flex-1">
                          <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors mb-2">
                            {achievement.title}
                          </h3>
                        <p className="text-muted-foreground mb-3">
                          {achievement.description}
                        </p>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1 text-primary">
                            <Calendar className="h-4 w-4" />
                            <span>{achievement.date}</span>
                          </div>
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <BookOpen className="h-4 w-4" />
                            <span>{achievement.type}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Spacer for alternating layout */}
                <div className="flex-1 hidden lg:block"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Achievements;