import { Heart, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-12 border-t border-border/50 relative">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          {/* Logo and Description */}
          <div className="text-center md:text-left">
            <div className="font-bold text-xl gradient-text mb-2">
              Deekshika G
            </div>
            <p className="text-muted-foreground text-sm max-w-md">
              Full Stack Developer & Cloud Enthusiast passionate about creating 
              innovative solutions and exploring new technologies.
            </p>
          </div>

          {/* Copyright and Built with */}
          <div className="text-center md:text-right">
            <p className="text-muted-foreground text-sm mb-2">
              © 2024 Deekshika G. All rights reserved.
            </p>
            <p className="text-muted-foreground text-sm flex items-center justify-center md:justify-end gap-1">
              Built with <Heart className="h-4 w-4 text-red-500" /> using React & TypeScript
            </p>
          </div>
        </div>

        {/* Back to Top Button */}
        <div className="flex justify-center mt-8">
          <Button
            onClick={scrollToTop}
            variant="outline"
            size="sm"
            className="border-primary/50 hover:bg-primary/10 transition-all duration-300 hover:scale-105"
          >
            <ArrowUp className="h-4 w-4 mr-2" />
            Back to Top
          </Button>
        </div>
      </div>

      {/* Background Decoration */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
    </footer>
  );
};

export default Footer;