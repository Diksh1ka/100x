import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroWorkspace from '@/assets/hero-workspace.jpg';

const Hero = () => {
  const scrollToAbout = () => {
    const element = document.querySelector('#about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 left-10 w-20 h-20 bg-primary/20 rounded-full blur-xl animate-float"></div>
        <div className="absolute bottom-32 right-20 w-32 h-32 bg-accent/20 rounded-full blur-xl animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-primary/30 rounded-full blur-lg animate-float" style={{ animationDelay: '4s' }}></div>
      </div>

      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        {/* Text Content */}
        <div className="text-center lg:text-left animate-slide-up">
          <div className="mb-6">
            <span className="text-primary font-medium">👋 Hello, I'm</span>
            <h1 className="text-5xl lg:text-7xl font-bold mt-2 mb-4">
              <span className="gradient-text">Deekshika G</span>
            </h1>
            <div className="text-xl lg:text-2xl text-muted-foreground mb-2">
              Passionate <span className="text-primary font-semibold">Full Stack Developer</span>
            </div>
            <div className="text-xl lg:text-2xl text-muted-foreground">
              and <span className="text-primary font-semibold">Cloud Enthusiast</span>
            </div>
          </div>

          <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
            Passionate about creating efficient solutions, creating efficient solutions and 
            exploring cloud technologies, learning and turning ideas into reality.
          </p>

          {/* Social Links */}
          <div className="flex gap-4 justify-center lg:justify-start">
            <a 
              href="https://github.com/Diksh1ka" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-secondary/50 hover:bg-primary/20 transition-all duration-300 hover:scale-110"
            >
              <Github className="h-5 w-5" />
            </a>
            <a 
              href="https://www.linkedin.com/in/deekshika-g-023514307" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-secondary/50 hover:bg-primary/20 transition-all duration-300 hover:scale-110"
            >
              <Linkedin className="h-5 w-5" />
            </a>
            <a 
              href="mailto:deekshika2003@gmail.com"
              className="p-3 rounded-full bg-secondary/50 hover:bg-primary/20 transition-all duration-300 hover:scale-110"
            >
              <Mail className="h-5 w-5" />
            </a>
          </div>
        </div>

        {/* Hero Image */}
        <div className="relative animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <div className="hero-card floating-element">
            <img 
              src={heroWorkspace} 
              alt="Modern developer workspace"
              className="w-full h-auto rounded-lg object-cover"
            />
          </div>
          {/* Floating decorative elements */}
          <div className="absolute -top-4 -right-4 w-8 h-8 bg-primary rounded-full animate-glow"></div>
          <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-accent rounded-full animate-glow" style={{ animationDelay: '1s' }}></div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button 
          onClick={scrollToAbout}
          className="text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowDown className="h-6 w-6" />
        </button>
      </div>
    </section>
  );
};

export default Hero;