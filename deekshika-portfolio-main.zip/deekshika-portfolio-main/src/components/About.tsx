import { Code, Database, Cloud, Lightbulb, Users, Clock, Target, Heart } from 'lucide-react';

const About = () => {
  const skills = [
    {
      category: "Programming Languages",
      icon: Code,
      items: ["Python", "SQL", "JavaScript", "HTML5", "CSS3"]
    },
    {
      category: "Frameworks & Libraries",
      icon: Database,
      items: ["Flask", "React", "Tailwind CSS"]
    },
    {
      category: "Cloud & Tools",
      icon: Cloud,
      items: ["AWS", "Google Cloud", "Power BI", "Git"]
    },
    {
      category: "Development Tools",
      icon: Database,
      items: ["VS Code", "Spyder", "GitHub", "Command Line", "Postman"]
    }
  ];

  const personalInfo = [
    { icon: Users, label: "Languages", value: "English, Kannada, Telugu, Hindi" },
    { icon: Heart, label: "Hobbies", value: "Pencil Sketching, Reading Books" },
    { icon: Lightbulb, label: "Education", value: "B.E. Computer Science" }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            About <span className="gradient-text">Me</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            I'm a skilled software developer with a passion for creating innovative, user-focused solutions. I excel at designing and building scalable, efficient platforms that deliver real impact, combining technical expertise with a deep understanding of user needs. A quick learner with a drive for continuous improvement, I'm eager to bring fresh ideas and dedication to every project I take on. Let's work together to make your vision a reality!
          </p>
        </div>

        {/* Core Skills Section */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {[
            { title: "Problem Solving", icon: Target },
            { title: "Communication", icon: Users },
            { title: "Time Management", icon: Clock },
            { title: "Adaptability", icon: Lightbulb }
          ].map((skill, index) => (
            <div key={index} className="glow-card text-center group">
              <div className="mb-4">
                <div className="w-12 h-12 mx-auto bg-gradient-primary rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                  <skill.icon className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-semibold text-foreground">{skill.title}</h4>
              </div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Personal Information */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold mb-6">Personal Information</h3>
            <div className="grid gap-4">
              {personalInfo.map((info, index) => (
                <div key={index} className="glow-card">
                  <div className="flex items-start gap-4">
                    <div className="p-2 rounded-lg bg-primary/20">
                      <info.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{info.label}</h4>
                      <p className="text-muted-foreground">{info.value}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Section */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold mb-6">Skills & Expertise</h3>
            <div className="space-y-6">
              {skills.map((skillGroup, index) => (
                <div key={index} className="glow-card">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-primary/20">
                      <skillGroup.icon className="h-5 w-5 text-primary" />
                    </div>
                    <h4 className="font-semibold text-foreground">{skillGroup.category}</h4>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {skillGroup.items.map((skill, skillIndex) => (
                      <span 
                        key={skillIndex}
                        className="px-3 py-1 bg-secondary rounded-full text-sm text-secondary-foreground border border-border/50"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Role Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { title: "Frontend Developer", icon: Code, description: "Building responsive and interactive user interfaces" },
            { title: "Backend Developer", icon: Database, description: "Creating robust server-side applications and APIs" },
            { title: "Cloud Enthusiast", icon: Cloud, description: "Exploring AWS and cloud computing technologies" },
            { title: "Problem Solver", icon: Lightbulb, description: "Analyzing challenges and creating innovative solutions" }
          ].map((role, index) => (
            <div key={index} className="glow-card text-center group">
              <div className="mb-4">
                <div className="w-16 h-16 mx-auto bg-gradient-primary rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <role.icon className="h-8 w-8 text-white" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{role.title}</h4>
                <p className="text-sm text-muted-foreground">{role.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;